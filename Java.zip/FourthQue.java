import java.util.Scanner;
class Bank{
	double balance;
	
	public Bank() {
		balance=0.0;
	}
	
	public void Deposite(double amount) {
		if(amount>0) {
			balance+=amount;
			System.out.println("Amount deposited, Balance is "+balance);
		}
		else {
			System.out.println("Invalid input, Please check");
		}
	}
	public void Withdraw(double amount) {
		if(amount<=balance && amount>0) {
			balance-=amount;
			System.out.println("Amount withdraw, Balance is "+balance);
		}
		else {
			System.out.println("Insufficient balance or Invalid input");
		}
	}
	public double Balance() {
		return balance;
	}
}

public class FourthQue {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Bank b=new Bank();
		
		double amount;
		int choice;
		
		do {
			System.out.println("Bank Menu :");
			System.out.println("For deposite-enter 1");
			System.out.println("For Withdraw-enter 2");
			System.out.println("For Balance-enter 3");
			System.out.println("For exit-enter 4");
			System.out.println();
			System.out.println("Enter your choice : ");
			choice=sc.nextInt();
			
			switch(choice) {
				case 1:
					System.out.println("Enter amount to deposite : ");
					amount=sc.nextDouble();
					b.Deposite(amount);
					break;
					
				case 2:
					System.out.println("Enter amount to withdraw : ");
					amount=sc.nextDouble();
					b.Withdraw(amount);
					break;
					
				case 3:
					System.out.println("Current balnce is "+b.Balance());
					break;
					
				case 4:
					System.out.println("Exiting Program");
					break;
				
				default:
					System.out.println("Invalid operation");
					break;
				
			}
		}
		while(choice!=4);
		sc.close();
	}

}
