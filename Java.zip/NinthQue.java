import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class NinthQue {
    private static final int QUEUE_CAPACITY = 10;
    private static final int MAX_RANDOM_NUMBER = 100;
    private static final int NUM_VALUES_TO_PRODUCE = 20;

    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        Thread producerThread = new Thread(new Producer(queue));
        Thread consumerThread = new Thread(new Consumer(queue));

        producerThread.start();
        consumerThread.start();
    }

    static class Producer implements Runnable {
        private Queue<Integer> queue;

        public Producer(Queue<Integer> queue) {
            this.queue = queue;
        }

        @Override
        public void run() {
            Random random = new Random();
            for (int i = 0; i < NUM_VALUES_TO_PRODUCE; i++) {
                int value = random.nextInt(MAX_RANDOM_NUMBER);
                synchronized (queue) {
                    while (queue.size() == QUEUE_CAPACITY) {
                        try {
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    queue.add(value);
                    System.out.println("Produced: " + value);
                    queue.notifyAll();
                }
            }
        }
    }

    static class Consumer implements Runnable {
        private Queue<Integer> queue;

        public Consumer(Queue<Integer> queue) {
            this.queue = queue;
        }

        @Override
        public void run() {
            int sum = 0;
            for (int i = 0; i < NUM_VALUES_TO_PRODUCE; i++) {
                synchronized (queue) {
                    while (queue.isEmpty()) {
                        try {
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    int value = queue.poll();
                    sum += value;
                    System.out.println("Consumed: " + value);
                    queue.notifyAll();
                }
            }
            System.out.println("Sum of consumed values: " + sum);
        }
    }
}
