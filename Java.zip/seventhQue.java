import java.util.Scanner;

public class seventhQue {
    public static void binarySearch(int[] array, int target) {
        int low = 0;
        int high = array.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            if (array[mid] == target) {
            	System.out.println("Target value found at index " + mid); // Target found at index mid
            	return;
            } else if (array[mid] < target) {
                low = mid + 1;  // Search in the right half of the array
            } else {
                high = mid - 1;  // Search in the left half of the array
            }
        }

        System.out.println("Target value not found in the array.");  // Target not found in the array
        return;
    }

    public static void main(String[] args) {
        int[] sortedArray = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the target value to search: ");
        int target = scanner.nextInt();

        binarySearch(sortedArray, target);

        
        scanner.close();
    }
}

