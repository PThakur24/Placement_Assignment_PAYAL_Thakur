import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class sixthQue {

	public static void main(String[] args) {
        // Create a large data set of Person objects
        List<Person> people = new ArrayList<>();
        people.add(new Person("John", 25));
        people.add(new Person("Alice", 32));
        people.add(new Person("Bob", 28));
        people.add(new Person("Emily", 22));
        // Add more Person objects as needed...

        // Sorting the data by age
        List<Person> sortedByAge = people.stream()
                .sorted(Comparator.comparing(Person::getAge))
                .collect(Collectors.toList());

        // Filtering out people younger than 30
        List<Person> filteredByAge = people.stream()
                .filter(person -> person.getAge() >= 30)
                .collect(Collectors.toList());

        // Print the sorted data
        System.out.println("Sorted by age:");
        sortedByAge.forEach(System.out::println);

        // Print the filtered data
        System.out.println("\nFiltered by age (30 and above):");
        filteredByAge.forEach(System.out::println);
    }

    // Person class
    static class Person {
        private String name;
        private int age;

        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        @Override
        public String toString() {
            return "Person{" +
                    "name='" + name + '\'' +
                    ", age=" + age +
                    '}';
        }
    }
}

