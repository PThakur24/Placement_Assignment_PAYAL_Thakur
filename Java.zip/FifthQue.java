abstract class Shape {
    protected String color;

    public Shape(String color) {
        this.color = color;
    }

    public abstract double getArea();

    public void displayColor() {
        System.out.println("Color: " + color);
    }
}

class Circle extends Shape {
    private double radius;

    public Circle(String color, double radius) {
        super(color);
        this.radius = radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }
}

public class FifthQue {

	public static void main(String[] args) {
        Circle circle = new Circle("Red", 3.5);
        circle.displayColor();
        System.out.println("Area: " + circle.getArea());
    }

}

//Interface

interface Drawable {
    void draw();

    void resize(int width, int height);
}

class Circle implements Drawable {
    public void draw() {
        System.out.println("Drawing a circle");
    }

    public void resize(int width, int height) {
        System.out.println("Resizing the circle to width: " + width + " and height: " + height);
    }
}

public class InterfaceExample {
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.draw();
        circle.resize(5, 5);
    }
}

/*Key differences:

Abstract classes can have constructors, while interfaces cannot.
Abstract classes can have non-abstract methods with an implementation, while all methods in an interface are implicitly public and abstract.
A class can extend only one abstract class, but it can implement multiple interfaces.
Interfaces are more suited for defining contracts or behaviors that multiple unrelated classes can implement, while abstract classes are more suited for creating a common base class for a related set of classes.
I hope this helps in understanding the difference between abstract classes and interfaces!*/














