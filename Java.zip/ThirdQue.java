import java.util.Scanner;

class NegativeValueException extends Exception {
    public NegativeValueException(String message) {
        super(message);
    }
}

public class ThirdQue {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter an integer: ");
            int number = scanner.nextInt();

            if (number < 0) {
                throw new NegativeValueException("Negative numbers are not allowed.");
            }

            System.out.println("The entered number is: " + number);
        } catch (NegativeValueException e) {
            System.out.println("An exception occurred: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
