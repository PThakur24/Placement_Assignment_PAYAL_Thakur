class Parent{
	public Parent() {
		System.out.println("Parent class Constructor");
	}
}

class Child extends Parent{
	public Child() {
		super();
		System.out.println("Child class Constructor");
	}
	
}
public class SecQue {

	public static void main(String[] args) {
		Child c =new Child();
		

	}

}
/*Key points about constructors:

Constructors are special methods that are used to initialize objects of a class.
The name of the constructor must be the same as the class name.
Constructors do not have a return type, not even void.
Constructors can be overloaded, which means having multiple constructors with different parameters.
If a constructor is not explicitly defined in a class, a default constructor is provided by the compiler.
The super() keyword is used to invoke the constructor of the parent class. It must be the first statement in the child class constructor.*/