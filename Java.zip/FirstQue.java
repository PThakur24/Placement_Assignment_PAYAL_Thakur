interface Shape{
	double calArea();
	double calPerimeter();
}

class Circle implements Shape{
	private double radius;
	
	public Circle(double radius) {
		this.radius=radius;
	}
	@Override
	public double calArea() {
		return Math.PI * radius * radius;
	}
	
	public double calPerimeter() {
		return 2*Math.PI*radius;
	}
}

class Triangle implements Shape{
	private double side1;
	private double side2;
	private double side3;
	
	public Triangle(double side1,double side2,double side3) {
		this.side1=side1;
		this.side2=side2;
		this.side3=side3;
	}
	@Override
	public double calArea() {
		double s = (side1 + side2 + side3) / 2;
        return Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
	}
	
	public double calPerimeter() {
		return side1 + side2 + side3;
	}
}
public class FirstQue {

	public static void main(String[] args) {
		Circle c=new Circle(2.5);
		System.out.println("Area of Circle : "+c.calArea());
		System.out.println("Perimeter of Circle : "+c.calPerimeter());
		
		Triangle t=new Triangle(2.5,1.5,2.5);
		System.out.println("Area of Triangle : "+t.calArea());
		System.out.println("Perimeter of Yriangle : "+t.calPerimeter());
		

	}

}
