
public class FourteenQue {

}
